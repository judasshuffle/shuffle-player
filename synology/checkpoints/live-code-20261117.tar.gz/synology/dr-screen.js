/* Listener only: never calls station controls or loads a second audio stream. */
const player = document.getElementById('player');
const status = document.getElementById('status');
const button = document.getElementById('start');
const volumeSlider = document.getElementById('volume');
const presetDebug = document.getElementById('presetDebug');
const context = new (window.AudioContext || window.webkitAudioContext)();
const source = context.createMediaElementSource(player);
const analyser = context.createAnalyser();
analyser.fftSize = 1024;
const gain = context.createGain();
let volume = 100;
let reconnectTimer = null, retryDelay = 1000, playAttempt = 0, closed = false;
let scheduledDelay = 0;
function clearReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  scheduledDelay = 0;
}
function reconnect(delay = retryDelay) {
  if (closed || (reconnectTimer !== null && delay >= scheduledDelay)) return;
  clearReconnect();
  scheduledDelay = delay;
  status.textContent = `Stream interrupted. Reconnecting in ${delay / 1000}s…`;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    if (closed) return;
    retryDelay = Math.min(retryDelay * 2, 8000);
    // Reuse the existing element and audio graph, including gain and mute state.
    player.pause();
    player.load();
    start();
  }, delay);
}
source.connect(analyser);
analyser.connect(gain);
gain.connect(context.destination);
// Shufflizer's existing embedded runtime consumes this exact analyser.
window.playerAudio = {audioCtx: context, analyser, setMuted() {}};
window.currentTrackTitle = '';
const frame = document.createElement('iframe');
frame.src = '/visualizer/index.html?embed=1';
frame.title = 'Shufflizer live MP3';
frame.allow = 'autoplay';
document.getElementById('visualizer').append(frame);
let stationVersion = 0, visualTrackId = null, titleTrackId = null, manualVisual = null, appliedVisualKey = '';
let stationVisual = null, rendererVisual = null;
let musicTrack = null;
const MANUAL_VISUAL_KEY = 'shufflizer.screen.manual-preset';
function readManualVisual(trackId) {
  try {
    const saved = JSON.parse(localStorage.getItem(MANUAL_VISUAL_KEY) || 'null');
    return saved && saved.trackId === trackId ? saved : null;
  } catch (_) { return null; }
}
function writeManualVisual(detail) {
  manualVisual = {trackId: visualTrackId, bank: detail.bank, preset: detail.preset};
  appliedVisualKey = `${visualTrackId}|${detail.bank}|${detail.preset}`;
  try { localStorage.setItem(MANUAL_VISUAL_KEY, JSON.stringify(manualVisual)); } catch (_) {}
}
function showPresetDebug() {
  if (!presetDebug) return;
  const station = stationVisual ? `${stationVisual.bank} / ${stationVisual.preset}` : 'waiting';
  const renderer = rendererVisual ? `${rendererVisual.bank} / ${rendererVisual.preset} (${rendererVisual.effectId})` : 'waiting';
  presetDebug.textContent = `Station preset: ${station} · Renderer preset: ${renderer}`;
}
function applyStationTitle(station) {
  const track = station?.current;
  const trackId = track?.id;
  if (!trackId || trackId === titleTrackId || !frame.contentWindow?.SHUF_setTrackTitle) return;
  const artist = (track.artist || '').toString().trim();
  const title = (track.title || '').toString().trim();
  const text = artist && title ? `${artist} — ${title}` : (title || artist || '');
  if (!text) return;
  titleTrackId = trackId;
  frame.contentWindow.SHUF_setTrackTitle(text);
}
function applyStationVisual(station) {
  musicTrack = station?.current || null;
  const trackId = station?.current?.id;
  const visual = station?.visualizer;
  applyStationTitle(station);
  if (!trackId || !visual?.bank || !visual?.preset || !frame.contentWindow?.SHUF_setSelection) return;
  stationVisual = {bank: visual.bank, preset: visual.preset};
  showPresetDebug();
  if (trackId !== visualTrackId) {
    visualTrackId = trackId;
    manualVisual = readManualVisual(trackId);
    appliedVisualKey = '';
    if (!manualVisual) {
      try { localStorage.removeItem(MANUAL_VISUAL_KEY); } catch (_) {}
    }
  }
  if (manualVisual?.trackId === trackId) {
    const key = `${trackId}|${manualVisual.bank}|${manualVisual.preset}`;
    if (key !== appliedVisualKey) {
      frame.contentWindow.SHUF_setSelection(manualVisual.bank, manualVisual.preset, 'restore');
      appliedVisualKey = key;
    }
  } else {
    const key = `${trackId}|${visual.bank}|${visual.preset}`;
    if (key !== appliedVisualKey) {
      frame.contentWindow.SHUF_setSelection(visual.bank, visual.preset, 'auto');
      appliedVisualKey = key;
    }
    rendererVisual = frame.contentWindow.SHUF_rendererPreset || null;
    showPresetDebug();
  }
}
async function pollStationVisual() {
  try {
    const response = await fetch('/api/station?since=' + stationVersion);
    if (response.ok) {
      const station = await response.json();
      stationVersion = station.version || stationVersion;
      applyStationVisual(station);
    }
  } catch (_) {}
  setTimeout(pollStationVisual, 1000);
}
frame.addEventListener('load', () => {
  try { frame.contentWindow.addEventListener('shufflizer:preset-manual', event => writeManualVisual(event.detail || {})); } catch (_) {}
  try { frame.contentWindow.addEventListener('shufflizer:preset-applied', event => { rendererVisual = event.detail || null; showPresetDebug(); }); } catch (_) {}
  if (typeof fetch === 'function') pollStationVisual();
});
function showState() {
  const playing = !player.paused && context.state === 'running';
  status.textContent = playing ? `Live screen audio · volume ${volume}%` :
    'Autoplay blocked or audio suspended. Click Enable screen audio in DarkRide.';
  button.hidden = playing;
}
function start() {
  if (closed) return;
  clearReconnect();
  const attempt = ++playAttempt;
  if (context.state !== 'running') status.textContent = 'Audio suspended. Click Enable screen audio if it does not start.';
  // Both calls happen during the gesture; neither waits for the other.
  const resume = context.resume();
  const play = player.play();
  Promise.all([resume, play]).then(showState).catch(error => {
    if (closed || attempt !== playAttempt || error.name === 'AbortError') return;
    status.textContent = error.name === 'NotAllowedError' ?
      'DarkRide blocked autoplay. Click Enable screen audio.' :
      `Screen audio could not start (${error.name}). Click to retry.`;
    button.hidden = false;
    if (error.name !== 'NotAllowedError') reconnect();
  });
}
button.addEventListener('click', start);
function applyVolume(value) {
  volume = Math.max(0, Math.min(100, value));
  gain.gain.setValueAtTime(volume / 100, context.currentTime);
  volumeSlider.value = volume;
  showState();
}
volumeSlider.addEventListener('input', () => {
  applyVolume(Number(volumeSlider.value));
  if (bridgeConnected) window.EventBridge.emitWebEvent(JSON.stringify({sound: volume}));
});
context.addEventListener('statechange', showState);
player.addEventListener('playing', () => {
  clearReconnect();
  retryDelay = 1000;
  showState();
});
player.addEventListener('waiting', () => reconnect(5000));
player.addEventListener('stalled', () => reconnect(5000));
player.addEventListener('ended', () => reconnect());
player.addEventListener('error', () => reconnect());
let bridgeTimer;
let bridgeConnected = false;
let visualizerReady = false;
frame.addEventListener('load', () => {
  visualizerReady = true;
  if (bridgeConnected) window.EventBridge.emitWebEvent(JSON.stringify({ready: true}));
});
function connectBridge() {
  const bridge = window.EventBridge;
  if (!bridge || !bridge.scriptEventReceived || !bridge.emitWebEvent) return;
  clearInterval(bridgeTimer);
  bridgeConnected = true;
  bridge.scriptEventReceived.connect(raw => {
    let message;
    try { message = typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (_) { return; }
    if (!message || typeof message.volume !== 'number' || !Number.isFinite(message.volume)) return;
    applyVolume(message.volume);
  });
  bridge.emitWebEvent(JSON.stringify({hello: true}));
  if (visualizerReady) bridge.emitWebEvent(JSON.stringify({ready: true}));
  // Optional sidecar: failure must not interrupt the established audio graph.
  try {
    window.ShufflizerMusic?.attach({context, source, player, bridge, track: () => musicTrack});
  } catch (error) { console.warn('Shufflizer music telemetry unavailable', error); }
}
bridgeTimer = setInterval(connectBridge, 100);
connectBridge();
start();
window.addEventListener('pagehide', () => {
  closed = true;
  ++playAttempt;
  clearReconnect();
  clearInterval(bridgeTimer);
  player.pause();
  context.close();
});
